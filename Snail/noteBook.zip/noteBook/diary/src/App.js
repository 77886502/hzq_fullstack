import './App.css';
import { Button } from 'antd-mobile';

function App() {
  return (
    <div className="App">
      <Button type="primary">测试</Button>
    </div>
  );
}

export default App;
