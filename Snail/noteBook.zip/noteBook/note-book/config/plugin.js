'use strict';

exports.cors = {
  enable: true,
  package: 'egg-cors',
};
exports.ejs = {
  enable: true,
  package: 'egg-view-ejs',
};
