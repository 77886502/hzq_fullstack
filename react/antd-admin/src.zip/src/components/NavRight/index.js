import React, { useEffect } from 'react';
import { Tag } from 'antd';
import { NavLink } from 'react-router-dom';
import axios from 'axios';
import './index.css';

const NavRight = () => {
    const [tagList, setTagList] = useEffect([])
    const getTagAPIList = () => {
        axios.get('./tags')
            .then(res => {
            
        })
    }
    useEffect(() => {
       getTagAPIList() 
    },[])

    return (
        <>
        </>
    )
}

export default NavRight