import * as React from 'react';

export const MembersPage: React.StatelessComponent<{}> = () => {
  return (
    <div className="row">
      <h2> Members Page</h2>
    </div>
  );
}